import random
mbstring=""
kbstring=""
f=open("resources\\file.txt", "w")
f.write("")
f.close()
for i in range(1000):
    kbstring = kbstring + str(random.choice(['a', 'b', 'c', 'd', 'e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']))
print("Generated kbstring")
for i in range(1000):
    mbstring = mbstring + kbstring
print("Generated mbstring, writing...")
f=open("resources\\file.txt", "a")
for i in range(1000):
    f.write(mbstring)
f.close()
print("Complete")