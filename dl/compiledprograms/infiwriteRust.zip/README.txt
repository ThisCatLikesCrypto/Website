Please run genfile.py first or it will error.

Ignore windows defender smartscreen.

The program makes and then deleted 1GB tempfiles. Not sure why you need this, but you do.