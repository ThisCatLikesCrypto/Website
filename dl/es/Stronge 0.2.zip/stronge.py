import ESDLang
print("welcome to stronge editor v0.1")
global filnam
filnam=input("choose a  filename: ")
filext=input("choose file type: ")
if filext=="" or filext == "\n" or filext == " \n":
    filnam+=".txt"
else:
    filnam+=filext
file=open(filnam, 'a+')

file.seek(0)
for line in file:
    print(":", line.strip())
loop = 2000
while loop > 1000:
    toprint=input(": ")
    if toprint == "savex":
        print("saving...")
        file.close()
        exit()
    elif toprint == "savrun":
        print("saving...")
        file.close()
        import ESDLang
        break
    elif toprint == "filclr":
        file.close()
        file=open(filnam,'w')
        file.write("")
        file.close()
        file=open(filnam, 'a+')
        print("started afresh \n")
    else:
        file.write(toprint+"\n")