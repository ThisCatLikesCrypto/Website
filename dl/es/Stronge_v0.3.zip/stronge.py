import ESDLang
import os
print("welcome to stronge editor v0.1")
global filnam
global file
global linenum
linenum=1
filnam=input("choose a  filename: ")
filext=input("choose file type: ")
if filext=="" or filext == "\n" or filext == " \n":
    filnam+=".txt"
else:
    filnam+=filext
file=open(filnam, 'a+')

def refre():
    linenum=1
    file.seek(0)
    for line in file:
        print(linenum, ":", line.strip())
        linenum += 1
    global newlinnum
    newlinnum=linenum
def clr():
    file = open(filnam, 'w')
    file.write("")
    file.close()
def inserttool(str):
    global file
    file.close()
    file = open(filnam, 'a+')
    file.seek(0)
    lines = file.readlines()
    file.seek(0)
    splitted=str.split()
    togo=int(splitted[1])
    if 1 <= togo <= len(lines):
        toprint = input(":: ".format(togo))
        lines[togo - 1] = toprint + '\n'
    file.close()
    clr()
    file = open(filnam, 'a+')
    file.writelines(lines)
    lop=300
    while lop>0:
        print()
        lop-=1
    file.close()
    file=open(filnam,'a+')
    refre()

file.seek(0)
for line in file:
    print(linenum, ":", line.strip())
    linenum+=1
loop = 2000
while loop > 0:
    print(linenum, end=' ')
    toprint=input(": ")
    if toprint == "savex":
        print("saving...")
        file.close()
        exit()
    elif toprint == "savrun":
        print("saving...")
        file.close()
        import ESDLang
        break
    elif toprint == "filclr":
        file.close()
        clr()
        file = open(filnam, 'a+')
        print("started afresh \n")
        linenum=1
    elif toprint.startswith("ins"):
        inserttool(toprint)
        linenum=newlinnum
    else:
        file.write(toprint+"\n")
        re=300
        while re >0:
            print()
            re-=1
        refre()
        linenum=newlinnum