import random
variablenames=[]
variablevals=[]
global file
from stronge import filnam
file = open(filnam, "r")

def radno():
    toprint=varval[7:]
    bound1=int(toprint[:1])
    bound2=int(toprint[2:])
    return random.randint(bound1,bound2)

def ins(str):
    msg= str[6:]
    varval=input(msg)
    return varval

#vars can only be 2 letter names
def vars():
    overtmod=0
    global varval
    varname=file.readline()
    type=file.readline()
    if type=="num\n":
        if varname in variablenames:
            fetch=variablenames.index(varname)
            variablenames.remove(varname[:2])
            variablenames.insert(fetch, varname[:2])
            overtmod=1
        else:
         variablenames.append(varname[:2])
         if overtmod==1:
          fetch=variablenames.index(varname[:2])
          varval=file.readline()
          if varval.startswith("radnom"):
               varval=radno()
          if varval.startswith("input"):
              varval = ins(varval)
          variablevals.pop(fetch)
          variablevals.insert(fetch, float(varval))
         else:
            varval=file.readline()
            if varval.startswith("radnom"):
                 varval=radno()
            if varval.startswith("input"):
                varval=ins(varval)
            variablevals.append(float(varval))
    else:
        if varname in variablenames:
            fetch=variablenames.index(varname)
            variablenames.remove(varname[:2])
            variablenames.insert(fetch, varname[:2])
            overtmod=1
        else:
         variablenames.append(varname[:2])
         if overtmod==1:
          fetch=variablenames.index(varname[:2])
          varval=file.readline()
          if varval.startswith("input"):
              varval = ins(varval)
          variablevals.pop(fetch)
          variablevals.insert(fetch, varval)
         else:
            varval=file.readline()
            if varval.startswith("input"):
                varval=ins(varval)
            variablevals.append(varval)
def printah():
    toprint=usin[6:]
    compo = toprint.split()
    compo = [part.replace(" ", "") for part in compo]
    for part in compo:
     if part.endswith("\n"):
        if part[:2] in variablenames:
            varname=part
            fetch=variablenames.index(varname)
            print(variablevals[fetch], end=" ")
        else:
            print(part, end=" ")
     else:
         if part in variablenames:
             varname = part
             fetch = variablenames.index(varname)
             print(variablevals[fetch], end=" ")
         else:
             print(part, end=" ")

    print()

print("executing... (weardlang 2.0)")
loop = 250
while loop >= 0:
    usin=file.readline()
    if usin.startswith("va"):
       vars()
    elif usin == "quit":
       exit()
    elif usin.startswith("write"):
       printah()
    loop -= 1