import weardlang
print("welcome to stronge editor v0.1")
global filnam
filnam=input("choose a  filename: ")
filext=input("choose file type: ")
if filext=="" or filext == "\n" or filext == " \n":
    filnam+=".txt"
else:
    filnam+=filext
file=open(filnam, 'w')
loop = 2000
while loop > 1000:
    toprint=input(":")
    if toprint == "savex":
        print("saving...")
        exit()
    elif toprint == "savrun":
        print("saving...")
        file.close()
        import weardlang
        break
    else:
        file.write(toprint+"\n")