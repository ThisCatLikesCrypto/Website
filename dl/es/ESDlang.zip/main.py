import random
from typing import List, Any
variablenames=[]
variablevals=[]
global file
file=open("trun.txt", "r")

def radno():
    toprint=varval[7:]
    bound1=int(toprint[:1])
    bound2=int(toprint[2:])
    return random.randint(bound1,bound2)

def ins(str):
    msg= str[6:]
    varval=input(msg).rstrip()
    return varval

#vars can only be 2 letter names
def vars():
    overtmod=0
    global varval
    varname=file.readline()
    type=file.readline()
    if type=="num\n":
        if varname in variablenames:
            fetch=variablenames.index(varname)
            variablenames.remove(varname[:2])
            variablenames.insert(fetch, varname[:2])
            overtmod=1
        else:
         variablenames.append(varname[:2])
         if overtmod==1:
          fetch=variablenames.index(varname[:2])
          varval=file.readline()
          if varval.startswith("radnom"):
               varval=radno()
          if varval.startswith("input"):
              varval = ins(varval)
          variablevals.pop(fetch)
          variablevals.insert(fetch, float(varval))
         else:
            varval=file.readline()
            if varval.startswith("radnom"):
                 varval=radno()
            if varval.startswith("input"):
                varval=ins(varval)
            variablevals.append(float(varval))
    else:
        if varname in variablenames:
            fetch=variablenames.index(varname)
            variablenames.remove(varname[:2])
            variablenames.insert(fetch, varname[:2])
            overtmod=1
        else:
         variablenames.append(varname[:2])
         if overtmod==1:
          fetch=variablenames.index(varname[:2])
          varval=file.readline()
          if varval.startswith("input"):
              varval = ins(varval)
          variablevals.pop(fetch)
          variablevals.insert(fetch, varval.rstrip("\n"))
         else:
            varval=file.readline()
            if varval.startswith("input"):
                varval=ins(varval.rstrip("\n"))
            variablevals.append(varval)
def printah():
    toprint=usin[6:]
    compo = toprint.split()
    compo = [part.replace(" ", "") for part in compo]
    for part in compo:
     if part.endswith("\n"):
        if part[:2] in variablenames:
            varname=part
            fetch=variablenames.index(varname)
            print(variablevals[fetch], end=" ")
        else:
            print(part, end=" ")
     else:
         if part in variablenames:
             varname = part
             fetch = variablenames.index(varname)
             print(variablevals[fetch], end=" ")
         else:
             print(part, end=" ")

    print()

def condcheck(input_list: List[Any]):
  if len(input_list) != 3:
      print("an if statement requires 3 arguments, ", len(input_list), "are given")
  else:
    val1=input_list[0]
    val2=input_list[2]
    val2=val2.rstrip()
    cond=input_list[1]
    if val1 in variablenames:
        fetch=variablenames.index(val1)
        val1=variablevals[fetch]
    if val2 in variablenames:
        fetch=variablenames.index(val2)
        val2=variablevals[fetch]
    if cond == ">=":
        if val1 >= val2:
            return True
        else:
            return False

    elif cond == "<=":
        if val1 <= val2:
            return True
        else:
            return False

    elif cond == "=":
        if val1 == val2:
            return True
        else:
            return False

    elif cond == "x":
        if val1 != val2:
            return True
        else:
            return False

    elif cond == ">":
        if val1 > val2:
            return True
        else:
            return False
    elif cond == "<":
        if val1 < val2:
            return True
        else:
            return False
    else:
        print("error: condition to judge if statement on is not properly defined")
def ifchecker(str):
    compost1=str.split()
    compost1.remove("if")
    cond=condcheck(compost1)
    if cond != True:
        ln=...
        while ln != "else\n":
            ln=file.readline()
print("executing... (ESDLang 3.0)")

loop = 250
while loop >= 0:
    usin=file.readline()
    if usin.startswith("va"):
       vars()
    elif usin == "quit":
       exit()
    elif usin.startswith("write"):
       printah()
    elif usin.startswith("if"):
        ifchecker(usin.rstrip())
    elif usin.startswith("else"):
        ln = ...
        while ln != "endstat\n" and ln != "endstat":
            ln = file.readline()
    elif usin.startswith("endstat"):
        print(end='')
    loop -= 1